
# AR Industries — Next.js Landing Page

This is a ready-to-deploy Next.js project (minimal) for **AR Industries** with packages, bundles, add-ons and a functional contact form.

## What it includes
- Landing page with: Hero, SMM packages, Content packages, AI Chatbot, Bundles, Add-ons
- Contact form that POSTs to `/api/contact`
- API route (`/api/contact`) forwards form data to **Formspree**
- Logo included at `public/logo.jpg` (replace if needed)

## How to make the contact form functional
This project uses **Formspree** to send form submissions to your email.

1. Create a free Formspree form:
   - Go to https://formspree.io and sign up.
   - Create a new form — you'll receive a form endpoint like `https://formspree.io/f/{id}`.

2. In Vercel (or your environment), set an environment variable:
   - `FORMSPREE_ENDPOINT` = `https://formspree.io/f/{your_id}`

3. Deploy to Vercel:
   - Push this project to GitHub.
   - Sign in to https://vercel.com and import the GitHub repository.
   - In the Vercel project settings, add the `FORMSPREE_ENDPOINT` environment variable as described above.
   - Deploy — Vercel will build and provide a live URL.

## Local development
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run dev server:
   ```bash
   npm run dev
   ```
3. To test contact locally, you can temporarily set `FORMSPREE_ENDPOINT` in your shell:
   ```bash
   export FORMSPREE_ENDPOINT='https://formspree.io/f/{your_id}'
   npm run dev
   ```

## Notes
- If you prefer not to use Formspree, the API route can be adapted to use SendGrid, Mailgun, or a custom SMTP provider (you'll need API keys).
- Replace `public/logo.jpg` with a transparent PNG if you have one for best results.
