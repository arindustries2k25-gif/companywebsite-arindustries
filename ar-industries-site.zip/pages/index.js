
import Head from 'next/head'
import Image from 'next/image'
import { useState } from 'react'

export default function Home(){
  const [status, setStatus] = useState('')
  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('sending')
    const form = new FormData(e.target)
    const res = await fetch('/api/contact', {
      method:'POST',
      body: JSON.stringify({
        name: form.get('name'),
        email: form.get('email'),
        message: form.get('message')
      }),
      headers: {'Content-Type':'application/json'}
    })
    const data = await res.json()
    if (res.ok) {
      setStatus('sent')
      e.target.reset()
    } else {
      setStatus('error')
    }
  }

  return (
    <>
      <Head>
        <title>AR Industries — Luxury Digital Solutions</title>
        <meta name="description" content="Social Media Management, Content Creation, AI Chatbots — RM pricing included" />
      </Head>
      <div className="container">
        <header className="header">
          <div className="logoRow">
            <Image src="/logo.jpg" alt="logo" width={60} height={60} />
            <div>
              <div style={{fontWeight:700}}>AR Industries</div>
              <div style={{color:'var(--muted)',fontSize:13}}>Luxury • Minimal • Strategic</div>
            </div>
          </div>
          <div>
            <button className="btn">Get a Proposal</button>
          </div>
        </header>

        <main style={{marginTop:28}}>
          <section style={{display:'flex',gap:24,alignItems:'center'}}>
            <div style={{flex:1}}>
              <h1 style={{fontSize:34,margin:0}}>Digital Growth for Ambitious Brands</h1>
              <p style={{color:'var(--muted)',maxWidth:640}}>We help businesses scale through Social Media Marketing, Premium Content Creation, and AI Chatbot solutions. Clear strategy, elegant design, measurable results.</p>
            </div>
            <div style={{width:360}}>
              <div className="card">
                <h3 style={{marginTop:0}}>Request Pricing</h3>
                <p style={{color:'var(--muted)'}}>Send us your brief and we’ll reply within one business day.</p>
                <form onSubmit={handleSubmit} style={{marginTop:10}}>
                  <div className="form-row">
                    <input name="name" required className="input" placeholder="Your name" />
                    <input name="email" required className="input" placeholder="Email" type="email" />
                    <textarea name="message" required rows={4} className="input" placeholder="Tell us about your project (goals, timeline, budget)" />
                    <button className="btn" type="submit">{status==='sending'?'Sending...':'Send Message'}</button>
                  </div>
                  <div style={{height:8}} />
                  {status === 'sent' && <div style={{color:'lightgreen'}}>Message sent — we’ll be in touch!</div>}
                  {status === 'error' && <div style={{color:'#ff6b6b'}}>There was an error sending the message.</div>}
                </form>
              </div>
            </div>
          </section>

          <section style={{marginTop:36}}>
            <h2>Social Media Marketing Packages</h2>
            <div className="grid" style={{marginTop:12}}>
              <div className="card">
                <h3>Starter — RM 845 / month</h3>
                <table className="table">
                  <tbody>
                    <tr><th>Includes</th><td>1 platform, 8 posts, captions, 1× monthly report</td></tr>
                  </tbody>
                </table>
              </div>
              <div className="card">
                <h3>Growth — RM 1,268 / month</h3>
                <table className="table">
                  <tbody>
                    <tr><th>Includes</th><td>2 platforms, 12 posts, 10 stories, 3 hrs/wk community mgmt, 1× strategy call</td></tr>
                  </tbody>
                </table>
              </div>
              <div className="card">
                <h3>Pro — RM 2,113 / month</h3>
                <table className="table">
                  <tbody>
                    <tr><th>Includes</th><td>3 platforms, 16 posts, 20 stories, 5 hrs/wk community mgmt, 2× strategy calls</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <section style={{marginTop:36}}>
            <h2>Content Creation Packages</h2>
            <div className="grid" style={{marginTop:12}}>
              <div className="card">
                <h3>Starter — RM 845 / month</h3>
                <p>6 static designs, 1 short-form edit, copywriting</p>
              </div>
              <div className="card">
                <h3>Plus — RM 1,268 / month</h3>
                <p>10 static designs, 3 short-form edits, thumbnails (3)</p>
              </div>
              <div className="card">
                <h3>Pro — RM 1,690 / month</h3>
                <p>15 static designs, 4 short-form edits, thumbnails (6), motion graphics</p>
              </div>
            </div>
          </section>

          <section style={{marginTop:36}}>
            <h2>AI Chatbot</h2>
            <div className="grid" style={{gridTemplateColumns:'1fr 1fr',gap:18,marginTop:12}}>
              <div className="card"><h3>Setup — RM 1,479 (one-time)</h3><p>Custom AI chatbot setup</p></div>
              <div className="card"><h3>Maintenance — RM 211 / month</h3><p>Monthly upkeep & optimization</p></div>
            </div>
          </section>

          <section style={{marginTop:36}}>
            <h2>All-In Bundles</h2>
            <div className="grid" style={{marginTop:12}}>
              <div className="card"><h3>Bundle A – Start — RM 1,712 / month</h3><p>SMM Starter + Content Starter + AI Maint. (+Setup RM 1,479)</p></div>
              <div className="card"><h3>Bundle B – Grow — RM 2,417 / month</h3><p>SMM Growth + Content Plus + AI Maint. (+Setup RM 1,479)</p></div>
              <div className="card"><h3>Bundle C – Scale — RM 3,413 / month</h3><p>SMM Pro + Content Pro + AI Maint. (+Setup RM 1,479)</p></div>
            </div>
          </section>

          <section style={{marginTop:36}}>
            <h2>Add-ons</h2>
            <div className="card">
              <h4>SMM Add-ons</h4>
              <ul>
                <li>Extra platform mgmt — RM 350–600 / month</li>
                <li>Paid ads management — RM 500–1,500 / month or 10–20% ad spend</li>
                <li>Influencer seeding — RM 100–300 / post</li>
              </ul>
              <h4 style={{marginTop:12}}>Content Add-ons</h4>
              <ul>
                <li>Extra reel edit — RM 120–300 / video</li>
                <li>On-site half-day shoot — RM 600–1,200</li>
                <li>Subtitles / CC — RM 30–80 / video</li>
              </ul>
            </div>
          </section>

          <div className="footer">© {new Date().getFullYear()} AR Industries • All rights reserved</div>
        </main>
      </div>
    </>
  )
}
