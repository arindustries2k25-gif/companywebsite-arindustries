
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' }); return;
  }
  const { name, email, message } = req.body || {};
  if (!name || !email || !message) {
    res.status(400).json({ error: 'Missing fields' }); return;
  }

  const endpoint = process.env.FORMSPREE_ENDPOINT;
  if (!endpoint) {
    res.status(500).json({ error: 'Formspree endpoint not configured. Set FORMSPREE_ENDPOINT in your environment.' });
    return;
  }

  try {
    const payload = {
      name,
      email,
      message,
      _subject: `New lead from AR Industries website: ${name}`,
    };
    const r = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (r.ok) {
      res.status(200).json({ ok: true });
    } else {
      const text = await r.text();
      res.status(502).json({ error: 'Formspree error', detail: text });
    }
  } catch (err) {
    res.status(500).json({ error: 'Server error', detail: err.message });
  }
}
