
# AR Industries — Single Page Next.js Landing

Clean Next.js + Tailwind single-page landing for AR Industries.

## What is included
- Single-page site with Hero, Services, Packages, Add-ons, Contact
- TailwindCSS configured
- Functional contact API that forwards to Formspree via FORMSPREE_ENDPOINT env var
- vercel.json included for smooth detection on Vercel

## Quick deploy (Vercel)
1. Push repo to GitHub (root must contain package.json)
2. Import to Vercel and deploy
3. Set environment variable:
   - FORMSPREE_ENDPOINT = https://formspree.io/f/{your_id}
4. Deploy. Site should be detected as Next.js automatically.
