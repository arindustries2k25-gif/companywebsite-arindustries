
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brandGold: "#d4af37",
        brandBlack: "#0a0a0a",
      },
    },
  },
  plugins: [],
}
