
import Head from 'next/head'
import Image from 'next/image'
import { useState } from 'react'

export default function Home(){
  const [status, setStatus] = useState('')
  async function handleSubmit(e){
    e.preventDefault()
    setStatus('sending')
    const form = new FormData(e.target)
    const payload = { name: form.get('name'), email: form.get('email'), message: form.get('message') }
    const res = await fetch('/api/contact', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    if (res.ok){ setStatus('sent'); e.target.reset(); } else { setStatus('error'); }
  }
  const siteTitle = 'AR Industries — Luxury Digital Solutions'
  const siteDesc = 'Social Media Marketing • Content Creation • AI Chatbots — MYR pricing & packages.'
  return (
    <>
      <Head>
        <title>{siteTitle}</title>
        <meta name="description" content={siteDesc} />
        <meta property="og:title" content={siteTitle} />
        <meta property="og:description" content={siteDesc} />
        <meta property="og:image" content="/logo.jpg" />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
      </Head>
      <div className="min-h-screen flex flex-col bg-white text-black">
        <header className="bg-white text-brandBlack p-6 shadow-sm">
          <div className="container header">
            <div className="logo">
              <Image src="/logo.jpg" alt="AR Industries" width={80} height={80} />
              <div>
                <div className="font-bold text-xl">AR Industries</div>
                <div className="text-sm text-gray-500">Luxury • Minimal • Strategic</div>
              </div>
            </div>
            <div><button className="btn">Get a Proposal</button></div>
          </div>
        </header>

        <main className="container" style={{paddingTop:30}}>
          <section className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl font-bold">Digital Growth for Ambitious Brands</h1>
              <p className="mt-4 text-gray-600 max-w-xl">We help businesses scale through Social Media Marketing, Premium Content Creation, and AI Chatbot solutions. Clear strategy, elegant design, measurable results.</p>
              <div className="mt-6 flex gap-4">
                <button className="btn">Request Pricing</button>
                <a href="#packages" className="text-sm text-gray-700 underline">View Packages</a>
              </div>
            </div>
            <div className="card">
              <h3 className="text-lg font-semibold">Request a Proposal</h3>
              <form onSubmit={handleSubmit} className="mt-3 space-y-3">
                <input name="name" className="input" placeholder="Your name" required />
                <input name="email" type="email" className="input" placeholder="Email" required />
                <textarea name="message" className="input" rows={4} placeholder="Tell us about your project (goals, timeline, budget)" required />
                <div><button type="submit" className="btn">{status==='sending'?'Sending...':'Send Message'}</button></div>
                {status==='sent' && <div style={{color:'green'}}>Message sent — we'll be in touch!</div>}
                {status==='error' && <div style={{color:'crimson'}}>Error sending message. Check your Formspree settings.</div>}
              </form>
            </div>
          </section>

          <section id="services" className="mt-16">
            <h2 className="text-2xl font-semibold text-brandGold">Services</h2>
            <div className="grid md:grid-cols-3 gap-6 mt-6">
              <div className="card"><h3 className="font-semibold">Social Media Marketing</h3><p className="text-sm text-gray-600 mt-2">Strategy, content, community management, and growth across Instagram, TikTok, Facebook & LinkedIn.</p></div>
              <div className="card"><h3 className="font-semibold">Content Creation</h3><p className="text-sm text-gray-600 mt-2">High-end static designs, reels/shorts, thumbnails, and brand templates crafted for conversions.</p></div>
              <div className="card"><h3 className="font-semibold">AI Chatbots</h3><p className="text-sm text-gray-600 mt-2">One-time setup with ongoing maintenance so leads get instant answers 24/7.</p></div>
            </div>
          </section>

          <section id="packages" className="mt-16">
            <h2 className="text-2xl font-semibold text-brandGold">Packages & Pricing (MYR)</h2>
            <div className="grid md:grid-cols-3 gap-6 mt-6">
              <div className="card"><h3 className="font-semibold">SMM Starter</h3><p className="text-sm text-gray-600 mt-2">RM 845 / month — 1 platform, 8 posts, captions, 1× monthly report</p></div>
              <div className="card"><h3 className="font-semibold">SMM Growth</h3><p className="text-sm text-gray-600 mt-2">RM 1,268 / month — 2 platforms, 12 posts, 10 stories, 3 hrs/wk community mgmt, 1× strategy call</p></div>
              <div className="card"><h3 className="font-semibold">SMM Pro</h3><p className="text-sm text-gray-600 mt-2">RM 2,113 / month — 3 platforms, 16 posts, 20 stories, 5 hrs/wk community mgmt, 2× strategy calls</p></div>
            </div>

            <div className="grid md:grid-cols-3 gap-6 mt-6">
              <div className="card"><h3 className="font-semibold">Content Starter</h3><p className="text-sm text-gray-600 mt-2">RM 845 / month — 6 static designs, 1 short-form edit, copywriting</p></div>
              <div className="card"><h3 className="font-semibold">Content Plus</h3><p className="text-sm text-gray-600 mt-2">RM 1,268 / month — 10 static designs, 3 short-form edits, thumbnails (3)</p></div>
              <div className="card"><h3 className="font-semibold">Content Pro</h3><p className="text-sm text-gray-600 mt-2">RM 1,690 / month — 15 static designs, 4 short-form edits, thumbnails (6), motion graphics</p></div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mt-6">
              <div className="card"><h3 className="font-semibold">AI Chatbot Setup</h3><p className="text-sm text-gray-600 mt-2">RM 1,479 one-time</p></div>
              <div className="card"><h3 className="font-semibold">AI Maintenance</h3><p className="text-sm text-gray-600 mt-2">RM 211 / month</p></div>
            </div>
          </section>

          <section id="addons" className="mt-16">
            <h2 className="text-2xl font-semibold text-brandGold">Add-ons</h2>
            <div className="card mt-4">
              <h4 className="font-semibold">SMM Add-ons</h4>
              <ul className="mt-2 text-sm text-gray-600 space-y-1"><li>Extra platform mgmt — RM 350–600 / month</li><li>Paid ads management — RM 500–1,500 / month or 10–20% ad spend</li><li>Influencer seeding — RM 100–300 / post</li></ul>
              <h4 className="font-semibold mt-4">Content Add-ons</h4>
              <ul className="mt-2 text-sm text-gray-600 space-y-1"><li>Extra reel edit — RM 120–300 / video</li><li>On-site half-day shoot — RM 600–1,200</li><li>Subtitles / CC — RM 30–80 / video</li></ul>
            </div>
          </section>

          <div className="footer">© {new Date().getFullYear()} AR Industries • All rights reserved</div>
        </main>

      </div>
    </>
  )
}
